<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="ride-page">

        <div id="ride-view" class="ride-card">
            <div class="ride-header">
                <span class="page-badge"><?php echo e(__('messages.active_ride')); ?></span>
                <h1><?php echo e(__('messages.your_ride_is_active')); ?></h1>
                <p><?php echo e(__('messages.ride_tracking_description')); ?></p>
            </div>

            <div class="ride-stats">
                <div class="ride-stat">
                    <span><?php echo e(__('messages.time')); ?></span>
                    <strong id="timer">00:00:00</strong>
                </div>

                <div class="ride-stat">
                    <span><?php echo e(__('messages.distance')); ?></span>
                    <strong><span id="distance">0.00</span> km</strong>
                </div>

                <div class="ride-stat">
                    <span><?php echo e(__('messages.price')); ?></span>
                    <strong><span id="price">0.00</span> €</strong>
                </div>
            </div>

            <div class="gps-status" id="gps-status">
                <?php echo e(__('messages.waiting_gps_permission')); ?>

            </div>

            <div id="ride-map"></div>

            <button id="end-ride-btn" class="ride-end-btn">
                <?php echo e(__('messages.end_ride')); ?>

            </button>
        </div>

        <div id="ride-summary" class="ride-card ride-summary-card" style="display:none">
            <div class="ride-header">
                <span class="page-badge"><?php echo e(__('messages.ride_summary')); ?></span>
                <h1><?php echo e(__('messages.ride_finished')); ?></h1>
                <p><?php echo e(__('messages.ride_summary_description')); ?></p>
            </div>

            <div class="ride-stats">
                <div class="ride-stat">
                    <span><?php echo e(__('messages.time')); ?></span>
                    <strong id="summary-time"></strong>
                </div>

                <div class="ride-stat">
                    <span><?php echo e(__('messages.distance')); ?></span>
                    <strong><span id="summary-distance"></span> km</strong>
                </div>

                <div class="ride-stat">
                    <span><?php echo e(__('messages.amount_no_vat')); ?></span>
                    <strong><span id="summary-price"></span> €</strong>
                </div>
            </div>

            <button id="pay-btn" class="ride-pay-btn">
                <?php echo e(__('messages.pay')); ?>

            </button>

            <div id="payment-success" class="payment-success" style="display:none">
                <h2>✅ <?php echo e(__('messages.payment_success')); ?></h2>
                <p><?php echo e(__('messages.amount_no_vat')); ?>: <strong><span id="paid-summa-bez-pvn"></span> €</strong></p>
                <p><?php echo e(__('messages.amount_with_vat')); ?>: <strong><span id="paid-summa-ar-pvn"></span> €</strong></p>
                <p><?php echo e(__('messages.method')); ?>: <strong><span id="paid-veids"></span></strong></p>
                <p><?php echo e(__('messages.date')); ?>: <strong><span id="paid-datums"></span></strong></p>
            </div>

            
        </div>

    </div>

    <script>
        const rideId = <?php echo e($ride->id); ?>;
        const csrfToken = "<?php echo e(csrf_token()); ?>";

        const rideI18n = {
            waitingGpsPermission: <?php echo json_encode(__('messages.waiting_gps_permission'), 15, 512) ?>,
            gpsNotSupported: <?php echo json_encode(__('messages.gps_not_supported'), 15, 512) ?>,
            allowGpsAccess: <?php echo json_encode(__('messages.allow_gps_access'), 15, 512) ?>,
            gpsActiveAccuracy: <?php echo json_encode(__('messages.gps_active_accuracy'), 15, 512) ?>,
            gpsPermissionDenied: <?php echo json_encode(__('messages.gps_permission_denied'), 15, 512) ?>,
            gpsPositionUnavailable: <?php echo json_encode(__('messages.gps_position_unavailable'), 15, 512) ?>,
            gpsRequestTimedOut: <?php echo json_encode(__('messages.gps_request_timed_out'), 15, 512) ?>,
            gpsErrorOccurred: <?php echo json_encode(__('messages.gps_error_occurred'), 15, 512) ?>,
            yourLocation: <?php echo json_encode(__('messages.your_location'), 15, 512) ?>,
            paymentCreationError: <?php echo json_encode(__('messages.payment_creation_error'), 15, 512) ?>,
            hourShort: <?php echo json_encode(__('messages.hour_short'), 15, 512) ?>,
            minuteShort: <?php echo json_encode(__('messages.minute_short'), 15, 512) ?>,
            secondShort: <?php echo json_encode(__('messages.second_short'), 15, 512) ?>,
        };

        let startTime = Date.now();
        let totalDistance = 0;
        let lastPosition = null;
        let watchId = null;

        let rideMap = null;
        let userMarker = null;
        let routePath = null;

        const gpsStatus = document.getElementById('gps-status');

        function formatTime(totalSeconds) {
            const hours = Math.floor(totalSeconds / 3600);
            const minutes = Math.floor((totalSeconds % 3600) / 60);
            const seconds = Math.floor(totalSeconds % 60);

            return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        }

        function formatTimeReadable(totalSeconds) {
            const hours = Math.floor(totalSeconds / 3600);
            const minutes = Math.floor((totalSeconds % 3600) / 60);
            const seconds = Math.floor(totalSeconds % 60);

            let parts = [];

            if (hours > 0) parts.push(`${hours}${rideI18n.hourShort}`);
            if (minutes > 0) parts.push(`${minutes}${rideI18n.minuteShort}`);
            parts.push(`${seconds}${rideI18n.secondShort}`);

            return parts.join(' ');
        }

        function getDistance(lat1, lng1, lat2, lng2) {
            const R = 6371;
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLng = (lng2 - lng1) * Math.PI / 180;

            const a =
                Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1 * Math.PI / 180) *
                Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLng / 2) *
                Math.sin(dLng / 2);

            return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        }

        function setGpsStatus(message, type = '') {
            gpsStatus.textContent = message;
            gpsStatus.className = 'gps-status';

            if (type) {
                gpsStatus.classList.add(type);
            }
        }

        let rideMapInitialized = false;

        window.initRideMap = function () {
            if (rideMapInitialized) return;
            rideMapInitialized = true;

            const defaultPosition = { lat: 56.9496, lng: 24.1052 };

            rideMap = new google.maps.Map(document.getElementById('ride-map'), {
                center: defaultPosition,
                zoom: 15,
            });

            routePath = new google.maps.Polyline({
                path: [],
                geodesic: true,
                strokeColor: '#44AAC9',
                strokeOpacity: 1.0,
                strokeWeight: 5,
                map: rideMap,
            });

            startGpsTracking();
        };

        function updateMapPosition(lat, lng) {
            if (!rideMap) return;

            const position = { lat, lng };

            if (!userMarker) {
                userMarker = new google.maps.Marker({
                    position,
                    map: rideMap,
                    title: rideI18n.yourLocation,
                });
            } else {
                userMarker.setPosition(position);
            }

            rideMap.panTo(position);

            const path = routePath.getPath();
            path.push(new google.maps.LatLng(lat, lng));
        }

        function startGpsTracking() {
            if (!navigator.geolocation) {
                setGpsStatus(rideI18n.gpsNotSupported, 'error');
                return;
            }

            setGpsStatus(rideI18n.allowGpsAccess, '');

            watchId = navigator.geolocation.watchPosition(
                (pos) => {
                    const { latitude, longitude, accuracy } = pos.coords;

                    setGpsStatus(
                        rideI18n.gpsActiveAccuracy.replace(':accuracy', Math.round(accuracy)),
                        'success'
                    );

                    if (lastPosition) {
                        const segmentDistance = getDistance(
                            lastPosition.lat,
                            lastPosition.lng,
                            latitude,
                            longitude
                        );

                        /*
                            Filtrs pret GPS "lēkāšanu":
                            - mazāk par 5m ignorē
                            - vairāk par 2km starp punktiem ignorē kā kļūdu
                        */
                        if (segmentDistance > 0.005 && segmentDistance < 2) {
                            totalDistance += segmentDistance;
                            document.getElementById('distance').textContent = totalDistance.toFixed(2);
                        }
                    }

                    lastPosition = {
                        lat: latitude,
                        lng: longitude,
                    };

                    updateMapPosition(latitude, longitude);
                },
                (error) => {
                    if (error.code === error.PERMISSION_DENIED) {
                        setGpsStatus(rideI18n.gpsPermissionDenied, 'error');
                    } else if (error.code === error.POSITION_UNAVAILABLE) {
                        setGpsStatus(rideI18n.gpsPositionUnavailable, 'error');
                    } else if (error.code === error.TIMEOUT) {
                        setGpsStatus(rideI18n.gpsRequestTimedOut, 'error');
                    } else {
                        setGpsStatus(rideI18n.gpsErrorOccurred, 'error');
                    }
                },
                {
                    enableHighAccuracy: true,
                    maximumAge: 1000,
                    timeout: 10000,
                }
            );
        }

        setInterval(() => {
            const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
            document.getElementById('timer').textContent = formatTime(elapsedSeconds);

            const mins = elapsedSeconds / 60;
            const price = (mins * 0.10) + (totalDistance * 0.20);

            document.getElementById('price').textContent = price.toFixed(2);
        }, 1000);

        document.getElementById('end-ride-btn').addEventListener('click', async () => {
            if (watchId !== null) {
                navigator.geolocation.clearWatch(watchId);
            }

            const response = await fetch(`/ride/${rideId}/end`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrfToken,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify({
                    distance: totalDistance
                })
            });

            if (response.ok) {
                const data = await response.json();

                document.getElementById('ride-view').style.display = 'none';
                document.getElementById('ride-summary').style.display = 'block';

                document.getElementById('summary-time').textContent = formatTimeReadable(data.seconds);
                document.getElementById('summary-distance').textContent = data.distance.toFixed(2);
                document.getElementById('summary-price').textContent = data.cena.toFixed(2);
            }
        });

        document.getElementById('pay-btn').addEventListener('click', async () => {
            const response = await fetch(`/ride/${rideId}/pay`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrfToken,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
            });

            if (response.ok) {
                const data = await response.json();
                window.location.href = data.url;
            } else {
                const error = await response.json();
                alert(error.error || rideI18n.paymentCreationError);
            }
        });

        document.addEventListener('DOMContentLoaded', () => {
            if (window.google && google.maps && document.getElementById('ride-map')) {
                window.initRideMap();
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/ride.blade.php ENDPATH**/ ?>