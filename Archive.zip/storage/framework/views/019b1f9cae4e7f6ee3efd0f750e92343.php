<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Admin panelis</h1>

    <div class="admin-stats">
        <div class="stat-card">
            <span class="stat-number"><?php echo e($stats['lietotaji']); ?></span>
            <span class="stat-label">Lietotāji</span>
        </div>
        <div class="stat-card">
            <span class="stat-number"><?php echo e($stats['masinas']); ?></span>
            <span class="stat-label">Mašīnas</span>
        </div>
        <div class="stat-card">
            <span class="stat-number"><?php echo e($stats['rezervacijas']); ?></span>
            <span class="stat-label">Rezervācijas</span>
        </div>
        <div class="stat-card">
            <span class="stat-number"><?php echo e($stats['braucieni']); ?></span>
            <span class="stat-label">Braucieni</span>
        </div>
        <div class="stat-card">
            <span class="stat-number"><?php echo e($stats['verifikacijas']); ?></span>
            <span class="stat-label">Verifikacijas</span>
        </div>
        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/index.blade.php ENDPATH**/ ?>