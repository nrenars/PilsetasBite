<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="review-page">
        <div class="review-card">
    
            <div class="review-header">
                <span class="page-badge"><?php echo e(__('messages.review')); ?></span>
                <h1><?php echo e(__('messages.rating')); ?></h1>
                <p><?php echo e(__('messages.review_description')); ?></p>
            </div>

            <form action="<?php echo e(route('review.submit', $ride->id)); ?>" method="POST" class="review-form">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="vertejums"><?php echo e(__('messages.rating')); ?></label>
                    <select name="vertejums" id="vertejums" required>
                        <option value=""><?php echo e(__('messages.select')); ?></option>
                        <option value="1">1 - <?php echo e(__('messages.poor')); ?></option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5 - <?php echo e(__('messages.excellent')); ?></option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="komentars"><?php echo e(__('messages.comment')); ?></label>
                    <textarea
                        name="komentars"
                        id="komentars"
                        rows="7"
                        required
                        placeholder="Write your comment here..."
                    ></textarea>
                </div>

                <div class="review-actions">
                    <a href="/" class="review-secondary">
                        <?php echo e(__('messages.no_thanks')); ?>

                    </a>

                    <button type="submit" class="review-submit">
                        <?php echo e(__('messages.submit')); ?>

                    </button>
                </div>
            </form>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/review.blade.php ENDPATH**/ ?>