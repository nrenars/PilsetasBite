<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Mašīnas</h1>

    <p>
        <a href="<?php echo e(route('admin.masinas.create')); ?>" class="btn-small btn-warn" style="text-decoration: none;">
            Pievienot mašīnu
        </a>
    </p>

    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Reģ. Nr.</th>
                <th>Tehn. apsk. term.</th>
                <th>Marka</th>
                <th>Modelis</th>
                <th>Gads</th>
                <th>Transmisija</th>
                <th>Degvielas tips</th>
                <th>Vietu skaits</th>
                <th>Lokācijas ID</th>
                <th>Platums</th>
                <th>Garums</th>
                <th>Statuss</th>
                <th>Degviela</th>
                <th>Baterija</th>
                <th>Darbības</th>
            </tr>
        </thead>

        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $masinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($m->id); ?></td>

                    <td><?php echo e($m->registracijas_nr); ?></td>

                    <td><?php echo e($m->tehniskas_apskates_termins); ?></td>

                    <td><?php echo e($m->modelis->marka ?? '-'); ?></td>

                    <td><?php echo e($m->modelis->modelis ?? '-'); ?></td>

                    <td><?php echo e($m->gads); ?></td>

                    <td><?php echo e($m->modelis->transmisija ?? '-'); ?></td>

                    <td><?php echo e($m->modelis->degvielas_tips ?? '-'); ?></td>

                    <td><?php echo e($m->modelis->vietu_skaits ?? '-'); ?></td>

                    <td><?php echo e($m->lokacija_id ?? '-'); ?></td>

                    <td><?php echo e($m->lokacija->platuma_gradi ?? '-'); ?></td>

                    <td><?php echo e($m->lokacija->garuma_gradi ?? '-'); ?></td>

                    <td><?php echo e($m->statuss); ?></td>

                    <td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($m->degvielas_limenis !== null): ?>
                            <?php echo e($m->degvielas_limenis); ?>%
                        <?php else: ?>
                            -
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>

                    <td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($m->baterijas_limenis !== null): ?>
                            <?php echo e($m->baterijas_limenis); ?>%
                        <?php else: ?>
                            -
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>

                    <td class="admin-actions">
                        <a href="<?php echo e(route('admin.masinas.edit', $m->id)); ?>" class="btn-small btn-warn" style="text-decoration: none;">
                            Rediģēt
                        </a>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($m->statuss === 'neaktīva'): ?>
                            <form method="POST" action="<?php echo e(route('admin.masinas.activate', $m->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>

                                <button type="submit" class="btn-small btn-warn">
                                    Aktivizēt
                                </button>
                            </form>
                        <?php else: ?>
                            <form method="POST" action="<?php echo e(route('admin.masinas.deactivate', $m->id)); ?>" onsubmit="return confirm('Deaktivizēt mašīnu?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>

                                <button type="submit" class="btn-small btn-danger">
                                    Deaktivizēt
                                </button>
                            </form>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </tbody>
    </table>

    <?php echo e($masinas->links()); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/admin/masinas.blade.php ENDPATH**/ ?>