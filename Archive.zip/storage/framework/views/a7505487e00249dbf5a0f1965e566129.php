<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>Vadītāja apliecību verifikācija</h1>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lietotaji->count() === 0): ?>
        <div class="stat-card" style="align-items: flex-start; margin-bottom: 1rem;">
            <div class="stat-number" style="font-size: 1.2rem;">Nav gaidošu verifikāciju</div>
            <div class="stat-label">
                Šobrīd nav lietotāju, kuri gaida vadītāja apliecības pārbaudi.
            </div>
        </div>
    <?php else: ?>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Lietotājs</th>
                    <th>E-pasts</th>
                    <th>Telefons</th>
                    <th>Apliecības nr.</th>
                    <th>Derīga līdz</th>
                    <th>Statuss</th>
                    <th>Attēls</th>
                    <th>Darbības</th>
                </tr>
            </thead>

            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $lietotaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lietotajs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($lietotajs->id); ?></td>

                        <td>
                            <?php echo e($lietotajs->pilns_vards ?? ($lietotajs->vards . ' ' . $lietotajs->uzvards)); ?>

                        </td>

                        <td><?php echo e($lietotajs->epasts); ?></td>

                        <td><?php echo e($lietotajs->telefons); ?></td>

                        <td>
                            <?php echo e($lietotajs->vaditaja_apliecibas_nr ?? '—'); ?>

                        </td>

                        <td>
                            <?php echo e($lietotajs->vaditaja_apliecibas_termins ?? '—'); ?>

                        </td>

                        <td>
                            <?php echo e($lietotajs->vaditaja_apliecibas_statuss ?? '—'); ?>

                        </td>

                        <td>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lietotajs->vaditaja_apliecibas_attels): ?>
                                <a
                                    href="<?php echo e(asset('storage/' . $lietotajs->vaditaja_apliecibas_attels)); ?>"
                                    target="_blank"
                                >
                                    Skatīt
                                </a>
                            <?php else: ?>
                                —
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </td>

                        <td>
                            <div class="admin-actions">
                                <form
                                    method="POST"
                                    action="<?php echo e(route('admin.verifikacija.apstiprinat', $lietotajs->id)); ?>"
                                    onsubmit="return confirm('Apstiprināt vadītāja apliecību?')"
                                >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <button type="submit" class="btn-small" style="background:#22c55e; color:#fff;">
                                        Apstiprināt
                                    </button>
                                </form>

                                <form
                                    method="POST"
                                    action="<?php echo e(route('admin.verifikacija.noraidit', $lietotajs->id)); ?>"
                                    onsubmit="return confirm('Noraidīt vadītāja apliecību?')"
                                >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <button type="submit" class="btn-small btn-danger">
                                        Noraidīt
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>

        <?php echo e($lietotaji->links()); ?>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/admin/verifikacija.blade.php ENDPATH**/ ?>