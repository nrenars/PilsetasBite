<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="reservations-page">

        <div class="reservations-header">
            <h1><?php echo e(__('messages.your_reservation')); ?></h1>
            <p><?php echo e(__('messages.your_reservation_desc')); ?></p>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="reservation-card">

                <div class="reservation-card-top">
                    <div>
                        <h2>
                            <?php echo e($reservation->masina->modelis->marka); ?>

                            <?php echo e($reservation->masina->modelis->modelis); ?>

                        </h2>
                    </div>

                    <div class="reservation-year">
                        <?php echo e($reservation->masina->gads); ?>

                    </div>
                </div>

                <div class="reservation-main-info">
                    <div class="registration-box">
                        <span><?php echo e(__('messages.registration_no')); ?></span>
                        <strong><?php echo e($reservation->masina->registracijas_nr); ?></strong>
                    </div>

                    <div class="reserved-time">
                        <span><?php echo e(__('messages.reserved_at')); ?></span>
                        <strong><?php echo e($reservation->created_at->format('d.m.Y H:i')); ?></strong>
                    </div>
                </div>

                <div class="reservation-details">
                    <div class="detail-item">
                        <span><?php echo e(__('messages.transmission')); ?></span>
                        <strong><?php echo e($reservation->masina->modelis->transmisija); ?></strong>
                    </div>

                    <div class="detail-item">
                        <span><?php echo e(__('messages.fuel_type')); ?></span>
                        <strong><?php echo e($reservation->masina->modelis->degvielas_tips); ?></strong>
                    </div>

                    <div class="detail-item">
                        <span><?php echo e(__('messages.seats')); ?></span>
                        <strong><?php echo e($reservation->masina->modelis->vietu_skaits); ?></strong>
                    </div>
                </div>

                <div class="reservation-actions">
                    <form action="<?php echo e(route('reservations.destroy', $reservation->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-cancel" type="submit">
                            <?php echo e(__('messages.cancel_reservation')); ?>

                        </button>
                    </form>

                    <form action="<?php echo e(route('ride.begin', $reservation->masina_id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-begin" type="submit">
                            <?php echo e(__('messages.begin_ride')); ?>

                        </button>
                    </form>
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-reservation-card">
                <div class="empty-icon">🚘</div>
                <h2><?php echo e(__('messages.no_active_reservation')); ?></h2>
                <p><?php echo e(__('messages.no_active_reservation_desc')); ?></p>
                <a href="/" class="empty-link"><?php echo e(__('messages.find_a_car')); ?></a>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/reservations.blade.php ENDPATH**/ ?>