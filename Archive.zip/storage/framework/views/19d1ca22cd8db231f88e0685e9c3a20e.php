<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div id="container">
        <div id="filter-container">    
            
            <form action="">
                <div id="filters">
            
                    <div id="year-range-container">
                        
                        <div id="year-range">
                            <input type="number" name="year-from" id="year-from" placeholder="<?php echo e(__('messages.year_from')); ?>">
                            -
                            <input type="number" name="year-to" id="year-to" placeholder="<?php echo e(__('messages.year_to')); ?>">
                        </div>
                    </div>

                    
                    <select name="" id="model-dropdown"> <option value=""><?php echo e(__('messages.models')); ?></option></select>
                    <select name="" id="fuel-dropdown"><option value=""><?php echo e(__('messages.fuel')); ?></option></select>
                    <select name="" id="transmission-dropdown"><option value=""><?php echo e(__('messages.transmission_filter')); ?></option></select>

                </div>
                <button id="filter-btn" type="submit"><?php echo e(__('messages.filter')); ?></button>
                <p id="filter-error"></p>
            </form>
        </div>
        <div id="map-and-card">
            <div id="map"></div> 
            <script>
                window.csrfToken = "<?php echo e(csrf_token()); ?>";
            </script>
            <div id="car-card"></div>
        </div>
    </div>

    <?php
        $hasVerifiedDriverLicense = auth()->check()
            && trim((string) auth()->user()->vaditaja_apliecibas_statuss) === 'deriga';

        $hasActiveReservation = auth()->check()
            && auth()->user()->rezervacija()
                ->where('statuss', 'aktīva')
                ->where('deriguma_beigas', '>', now())
                ->exists();
    ?>

    <script>
        window.masinas = <?php echo json_encode($masinas, 15, 512) ?>;
        window.hasVerifiedDriverLicense = <?php echo json_encode($hasVerifiedDriverLicense, 15, 512) ?>;
        window.hasActiveReservation = <?php echo json_encode($hasActiveReservation, 15, 512) ?>;
        window.csrfToken = <?php echo json_encode(csrf_token(), 15, 512) ?>;
    </script>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('login')): ?>
        <div class="h-14.5 hidden lg:block"></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>