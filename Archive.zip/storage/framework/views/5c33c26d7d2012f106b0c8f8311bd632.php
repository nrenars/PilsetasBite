<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="profile-page">

        <div class="profile-header">
            <h1><?php echo e(__('messages.profile')); ?></h1>
            <p><?php echo e(__('messages.profile_description')); ?></p>
        </div>

        <div class="profile-grid">

            
            <div class="profile-card">
                <div class="profile-card-top">
                    <div class="profile-avatar">
                        <?php echo e(strtoupper(substr($user->vards, 0, 1))); ?><?php echo e(strtoupper(substr($user->uzvards, 0, 1))); ?>

                    </div>

                    <div>
                        <h2><?php echo e($user->vards); ?> <?php echo e($user->uzvards); ?></h2>
                    </div>
                </div>

                <div class="profile-info">
                    <div class="profile-info-row">
                        <span><?php echo e(__('messages.first_name')); ?></span>
                        <strong><?php echo e($user->vards); ?></strong>
                    </div>

                    <div class="profile-info-row">
                        <span><?php echo e(__('messages.last_name')); ?></span>
                        <strong><?php echo e($user->uzvards); ?></strong>
                    </div>

                    <div class="profile-info-row">
                        <span><?php echo e(__('messages.email')); ?></span>
                        <strong><?php echo e($user->epasts); ?></strong>
                    </div>

                    <div class="profile-info-row">
                        <span><?php echo e(__('messages.phone_number')); ?></span>
                        <strong><?php echo e($user->telefons); ?></strong>
                    </div>

                    <div class="profile-info-row">
                        <span><?php echo e(__('messages.account_created')); ?></span>
                        <strong><?php echo e($user->created_at->format('d.m.Y')); ?></strong>
                    </div>
                </div>

                <div class="profile-actions">
                    <a href="<?php echo e(route('auth.edit')); ?>" class="profile-btn profile-btn-edit">
                        <?php echo e(__('messages.edit_profile')); ?>

                    </a>

                    <form 
                        action="<?php echo e(route('auth.destroy')); ?>" 
                        method="POST" 
                        onsubmit="return confirm(<?php echo json_encode(__('messages.delete_profile_confirm'), 15, 512) ?>)"
                    >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="profile-btn profile-btn-delete" type="submit">
                            <?php echo e(__('messages.delete_profile')); ?>

                        </button>
                    </form>
                </div>
            </div>

            
            <div class="rides-card">
                <div class="rides-header">
                    <h2><?php echo e(__('messages.ride_history')); ?></h2>
                    <p><?php echo e(__('messages.ride_history_description')); ?></p>
                </div>

                <div class="rides-list">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $rides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ride): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="ride-item">
                            <div class="ride-item-top">
                                <h3><?php echo e(__('messages.ride_number', ['id' => $ride->id])); ?></h3>

                                <?php
                                    $rideStatusKey = match($ride->statuss) {
                                        'aktīva' => 'ride_status_active',
                                        'pabeigta' => 'ride_status_completed',
                                        'atcelta' => 'ride_status_cancelled',
                                        default => 'ride_status_unknown',
                                    };
                                ?>

                                <span class="ride-status">
                                    <?php echo e(__('messages.' . $rideStatusKey)); ?>

                                </span>
                            </div>

                            <div class="ride-details">
                                <div>
                                    <span><?php echo e(__('messages.distance')); ?></span>
                                    <strong><?php echo e($ride->nobrauktais_attalums); ?> km</strong>
                                </div>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ride->maksajums): ?>
                                    <div>
                                        <span><?php echo e(__('messages.payment_date')); ?></span>
                                        <strong><?php echo e($ride->maksajums->maksajuma_datums); ?></strong>
                                    </div>
                                <?php else: ?>
                                    <div>
                                        <span><?php echo e(__('messages.payment')); ?></span>
                                        <strong><?php echo e(__('messages.not_paid_yet')); ?></strong>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="empty-rides">
                            <div class="empty-icon">🚗</div>
                            <h3><?php echo e(__('messages.no_rides_yet')); ?></h3>
                            <p><?php echo e(__('messages.no_rides_description')); ?></p>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/auth/profile.blade.php ENDPATH**/ ?>