<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PilsetasBite</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/script.js']); ?>
    <script src="https://kit.fontawesome.com/542c50e191.js" crossorigin="anonymous"></script>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">

</head>
<body>
    <nav>
        <a href="/"><img height="100px" src="<?php echo e(asset('images/logo.png')); ?>" alt="PilsetasBite logo"></a>
        <div id="lang-switcher">
            <a href="<?php echo e(route('lang.switch', 'en')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active-lang' => app()->getLocale() === 'en']); ?>">EN</a>
            |
            <a href="<?php echo e(route('lang.switch', 'lv')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active-lang' => app()->getLocale() === 'lv']); ?>">LV</a>
        </div>
        <div id="dropdown">
            <i id="profile-icon" class="fa-regular fa-circle-user"></i>
            <div id="dropdown-content">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                <ul>
                    <li>
                        <a href="<?php echo e(route('register')); ?>"><?php echo e(__('messages.register')); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('login')); ?>"><?php echo e(__('messages.login')); ?></a>
                    </li>
                </ul>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                    <ul id="auth-dropdown-menu">
                        <li>
                            <a href="<?php echo e(route('showProfile')); ?>"><?php echo e(__('messages.profile')); ?></a>
                        </li>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()->rezervacija()->exists()): ?>
                            <li id="reservations-menu-item">
                                <a href="<?php echo e(route('reservations.show')); ?>"><?php echo e(__('messages.reservations')); ?></a>
                            </li>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()->loma === 'admins'): ?>
                            <li>
                                <a href="<?php echo e(route('admin.index')); ?>"><?php echo e(__('messages.admin_panel')); ?></a>
                            </li>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <li id="logout-menu-item">
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit"><?php echo e(__('messages.logout')); ?></button>
                            </form>
                        </li>
                    </ul>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </nav>
    <main>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
            <div class="alert alert-error">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php echo e($slot); ?>

    </main>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
        <script>
            window.reservationsUrl = "<?php echo e(route('reservations.show')); ?>";
            window.reservationsText = "<?php echo e(__('messages.reservations')); ?>";
        </script>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <script>
        window.i18n = {
            year: <?php echo json_encode(__('messages.year'), 15, 512) ?>,
            seat_count: <?php echo json_encode(__('messages.seat_count'), 15, 512) ?>,
            fuel_battery: <?php echo json_encode(__('messages.fuel_battery'), 15, 512) ?>,
            fuel_level: <?php echo json_encode(__('messages.fuel_level'), 15, 512) ?>,
            battery: <?php echo json_encode(__('messages.battery'), 15, 512) ?>,
            no_data: <?php echo json_encode(__('messages.no_data'), 15, 512) ?>,

            make_reservation: <?php echo json_encode(__('messages.make_reservation'), 15, 512) ?>,
            begin_ride: <?php echo json_encode(__('messages.begin_ride'), 15, 512) ?>,
            license_required: <?php echo json_encode(__('messages.license_required'), 15, 512) ?>,
            already_active_reservation: <?php echo json_encode(__('messages.already_active_reservation'), 15, 512) ?>,
            car_not_available: <?php echo json_encode(__('messages.car_not_available'), 15, 512) ?>,
            error: <?php echo json_encode(__('messages.error'), 15, 512) ?>,
            reservation_successful: <?php echo json_encode(__('messages.reservation_successful'), 15, 512) ?>,
            license_not_valid: <?php echo json_encode(__('messages.license_not_valid'), 15, 512) ?>,
            error: <?php echo json_encode(__('messages.error'), 15, 512) ?>,

            years_positive: <?php echo json_encode(__('messages.years_positive'), 15, 512) ?>,
            year_from_greater: <?php echo json_encode(__('messages.year_from_greater'), 15, 512) ?>,
            invalid_year_range: <?php echo json_encode(__('messages.invalid_year_range'), 15, 512) ?>,
            no_cars_from: <?php echo json_encode(__('messages.no_cars_from'), 15, 512) ?>,

            statuses: {
                "pieejama": <?php echo json_encode(__('messages.status_available'), 15, 512) ?>,
                "rezervēta": <?php echo json_encode(__('messages.status_reserved'), 15, 512) ?>,
                "lietošanā": <?php echo json_encode(__('messages.status_in_use'), 15, 512) ?>
            }
        };
    </script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/map.js']); ?>
    <script>
        window.initGoogleMaps = function () {
            if (document.getElementById('ride-map') && typeof window.initRideMap === 'function') {
                window.initRideMap();
                return;
            }

            if (document.getElementById('map') && typeof window.initMap === 'function') {
                window.initMap();
            }
        };
    </script>

    <script
        src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('services.google_maps.key')); ?>&map_ids=<?php echo e(config('services.google_maps.map_id')); ?>&callback=initGoogleMaps"
        async
        defer>
    </script>
</body>
</html><?php /**PATH /var/www/html/resources/views/components/layout.blade.php ENDPATH**/ ?>